---
object_name: REEBOeK
designer: Verly Laurent
builder: Verly Laurent
category: armchair
tags: wood
Overall size: L604 x W486 x H506 mm
creation_date: 09-2013
contributors: none
derived_from: Bouctje
Origninal designer/author: Mathieu Gabiot
realisation_place: RealizeBxl
required_hardware: Jigsaw, Drill - Screw Driver - Saw
materials: OSB panel
license: Free Art Licence
client: Workshop Libre Objet
Improvement: change functionality to be used as armchair
Advantage: comfortable little seat and also a rocking chair
Disadvantage: need to add cushions
Terms of use: chair
---
sources ready for Conflict & Design - 7th Triennale at C-Mine Genk
