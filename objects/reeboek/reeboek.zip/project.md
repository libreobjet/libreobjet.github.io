---
object_name: REEBOeK
designer: Verly Laurent
builder: Verly Laurent
category: armchair
tags: wood
Overall size: L604 x W486 x H506 mm
creation_date: 2013-09-22
contributors:
derived_from: Bouctje
origninal_designer: Mathieu Gabiot
realisation_place: RealizeBxl
required_hardware: [Jigsaw, Drill, Screw Driver, Saw]
materials: OSB panel
license: Free Art License
client: Workshop Libre Objet
---
sources ready for Conflict & Design - 7th Triennale at C-Mine Genk

- Improvement: change functionality to be used as armchair
- Advantage: comfortable little seat and also a rocking chair
- Disadvantage: need to add cushions
- Terms of use: chair
