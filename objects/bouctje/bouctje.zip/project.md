---
object_name: Bouctje
designer: Mathieu Gabiot
builder: Mathieu Gabiot
category: bookcase
tags: wood
creation_date: 01-2013
contributors:
derived_from:
realisation_place: Brussels
required_hardware: [hand saw, circular saw, drill driver, drill bit 3mm, sander, sand paper]
license: Free Art Licence
client:
---
Reduced version of Le Bouc bookshelf, Bouctje collects a small selection of books and presents it on a table, stand, or shelf. Lightweight and compact, it should be shipped flat in the near future. Now, Bouctje is open. Fell free to download instructions and sources to copy, modify and redistribute it under same license.
