---
object_name: Multi
designer: Jeromine Massart
builder: [Jeromine Massart, Frederic Monaux]
category: lamp
tags: wood
creation_date: 2014-01-01
contributors:
derived_from:
realisation_place: Nalinnes
required_hardware: [jigsaw, circular saw, drill, Wood glue or not, sander, sand paper]
license: Free Art License
client: Jeromine Massart - Arts²
---
Ambient and reading lamp. Feel free to download instructions and sources to copy, modify and redistribute it under the same license.
