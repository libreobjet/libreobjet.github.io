---
object_name: Multi
designer: Jeromine Massart
builder: Jeromine Massart and Frederic Monaux
category: lamp
tags: wood
creation_date: 01-2014
contributors: none
derived_from: none
realisation_place: Nalinnes
required_hardware: [jigsaw, circular saw, drill, Wood glue or not, sander, sand paper]
license: Free Art Licence
client: Jeromine Massart - Arts²
---
Ambient and reading lamp. Feel free to download instructions and sources to copy, modify and redistribute it under the same license.
