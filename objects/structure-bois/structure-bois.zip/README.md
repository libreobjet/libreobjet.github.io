STRUCTURE BOIS
==============

_Structure Bois is a display to show different kind of graphic design projects_ 

> I created this structure in 2015, in the context of my jury of master in art school, ERG in Brussels. My structure is inspired by a device, saw at UDK in Berlin during my Erasmus.
The idea was to create a display which allow to show my graphic design projects.
It was different kind of works: books, posters, papers, objects and the challenge was to make only one device for all of them.

> My goal was to make a lightly structure, modular and dismountable.
The several holes in the wooden boards, allow flexibility of assembly. Indeed this modularity is thought in order to adjust the structure according to the projects and situation.

A project released under a CERN Open Hardware License 1.2
