uHbench
=======

**The urban Hacker bench. Turn a standard Epal-Eur pallet into a public bench.**

The **uHbench** (v 1.5) is a libre object designed by [Julien Deswaef](http://xuv.be)  
Made with love and f/los software (Blender, Freestyle, Inkscape, Bash, XMLStarlet, Git & Gnu/Linux)  
You are encouraged to share, copy, modify, distribute and/or use it for any purpose.  
This project is copyleft and licensed under the **Free Art License** 1.3.

[More info...](http://xuv.be/uH-bench-open-source-public-bench.html)

![](https://raw.githubusercontent.com/xuv/uhbench/master/uhbench.gif)
