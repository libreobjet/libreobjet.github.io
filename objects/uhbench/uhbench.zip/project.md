---
object_name: uHbench
designer: Julien Deswaef
builder: Julien Deswaef
category: urban furniture
tags: [upcycle, urban, pallet]
overall_size:
creation_date: 2012-04-15
contributors:
derived_from:
original_designer:
realisation_place: Rue Jean d'Ardenne, Brussels
required_hardware: [hammer, saw, crowbar]
materials: [EPAL-EUR pallet, nails]
license: Free Art License
client: 
---
A public/garden bench from a standard euro pallet in a couple easy steps. Almost no wood pieces are left out. You could also reuse the nails.
