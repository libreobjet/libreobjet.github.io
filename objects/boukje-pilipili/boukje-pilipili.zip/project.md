---
object_name: Bouctje Pili-Pili
designer: Gregoire Vigneron
builder: Gregoire Vigneron
category: bookcase
tags: wood
Overall size: L326 x W254 x H401 mm
creation_date: 09-2013
contributors: none
derived_from: Bouctje
Origninal designer/author: Mathieu Gabiot
realisation_place: RealizeBxl
required_hardware: laser cutter, hand saw, wood chisel, sander, sand paper
materials: OSB panel, sandows
license: Free Art Licence
client: Workshop Libre Objet
Improvement: scaled to display other DIN sheet paper, change panel type like plywood to improve laser cutting
Advantage: low cost, flat kit unmountable, optimized drop wood
Disadvantage: Laser cutter needed to cut
Terms of use: bookshelf use only
---
