---
object_name: WimClip
designer: [Wim Van Raemdonck]
builder: Bram Hermans
category: PaperClip
tags: Plastic
overall_size: 40 x 20 x 8 mm
creation_date: 2013-12-01
contributors: [Bram Hermans for .STL-file, Mathieu Gabiot for adding “CERN OHL” on the WimClip]
original_designer: Wim Van Raemdonck
realisation_place: Lier, between Antwerp and Brussels , Belgium
required_hardware: [3D Printer, CutterKnife]
materials: ABS Plastic Filament
license: ﻿CERN Open Hardware Licence v1.2
client: Libre Objet
---
Double sided paperclip
