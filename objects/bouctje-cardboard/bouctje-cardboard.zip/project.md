---
object_name: Bouctje cardboard
designer: Camille Gabrieli
builder: Camille Gabrieli
category: Side Table & Bookstand
tags: wood
overall_size: 184 x 120 x 161 mm
creation_date: 2013-09-22
contributors:
derived_from: Bouctje
origninal_designer: Mathieu Gabiot
realisation_place: RealizeBxl
required_hardware: laser cutter
materials: cardboard 2 layers
license: Free Art License
client: Workshop Libre Objet
---

- Advantage: lightweight version, one piece to fold
- Disadvantage: limited to hold heavy books
