---
object_name: Bouctje cardboard
designer: Camille Gabrieli
builder: Camille Gabrieli
category: Side Table & Bookstand
tags: wood
Overall size: 184 x 120 x 161 mm
creation_date: 09-2013
contributors: none
derived_from: Bouctje
Origninal designer/author: Mathieu Gabiot
realisation_place: RealizeBxl
required_hardware: laser cutter
materials: cardboard 2 layers
license: Free Art Licence
client: Workshop Libre Objet
Improvement:
Advantage: lightweight version, one piece to fold
Disadvantage: limited to hold heavy books
---
