---
object_name: OSP Desk
designer: [Nonpareil]
builder: [Mathieu Gabiot]
category: furniture
tags: [desk, Open Source Publishing, funiture]
overall_size: 2400x700x718mm
creation_date: 2016-06-29
contributors: # List of contributors
derived_from: # Name of the object(s) it was derived from (in case of remixes)
original_designer: # Name of the previous designer(s) (in case of remixes)
realisation_place: Brussels
required_hardware: [panel saw, biscuit joiner, biscuits, clamps]
materials: Polish pine plywood 18mm
license: ﻿CERN Open Hardware Licence v1.2
client: OSP asbl
---

A simple desk that can be easily mount and unmount, two comfortable places with the
ability to work face to face or on the side. Some little storage, close to hand for daily
stuff. A mobile printer module for A3 printer with storage for two sizes of sheets.
