---
object_name: Bouctjje
designer: Thomas De Ridder
builder: Thomas De Ridder
category: Bookstand
tags: wood
overall_size: 377 x 308 x 593 mm
creation_date: 2013-09-22
contributors:
derived_from: Bouctje
original_designer: Mathieu Gabiot
realisation_place: RealizeBxl
required_hardware: [Drill, Screw Driver, Saw, Jigsaw]
materials: OSB panel
license: Free Art License
client: Workshop Libre Objet
---

- Improvement: adding one level
- Advantage: expand storage
- Disadvantage: Less portable, increased complexity
- Terms of use: bookshelf only
