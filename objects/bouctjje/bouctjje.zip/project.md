---
object_name: Bouctjje
designer: Thomas De Ridder
builder: Thomas De Ridder
category: Bookstand
tags: wood
Overall size: 377 x 308 x 593 mm
creation_date: 09-2013
contributors: none
derived_from: Bouctje
Origninal designer/author: Mathieu Gabiot
realisation_place: RealizeBxl
required_hardware: Drill - Screw Driver - Saw - Jigsaw
materials: OSB panel
license: Free Art Licence
client: Workshop Libre Objet
Improvement: adding one level
Advantage: expand storage
Disadvantage: Less portable, increased complexity
Terms of use: bookshelf only
---
