---
object_name: BoBouctje
designer: Miguel Van Steenbrugge
builder: Miguel Van Steenbrugge
category: Side Table & Bookstand
tags: wood
overall_size: 830 x 400 x 410 mm
creation_date: 2013-09-22
contributors:
derived_from: Bouctje
origninal_designer: Mathieu Gabiot
realisation_place: RealizeBxl
required_hardware: [Drill, Screw Driver, Saw]
materials: OSB panel
license: Free Art License
client: Workshop Libre Objet
---
Sources ready for Conflict & Design - 7th Triennale at C-Mine Genk

- improvement: Addition of a side table to the bookstand but conceived as one single entity
- advantage: Increase of functionality
- disadvantage: Less portable
- terms_of_use: Socializing
