---
object_name: Bouctje3
designer: [Bourg Stefanie, Colart Vicky, Massart Jeromine]
builder: [Bourg Stefanie, Colart Vicky, Massart Jeromine]
category: Showcase bookcase
tags: wood
overall_size: L376 x W308 x H333 mm
creation_date: 10-2013
derived_from: Bouctje
origninal_designer: Mathieu Gabiot
realisation_place: Arts2 - Mons
required_hardware: [jigsaw, hand saw, wood chisel, sander, sand paper]
materials: [plywood panel, screws]
license: Free Art Licence
client: Workshop Libre Objet
improvement: stackability
advantage: minimal modification form the original design
disadvantage: limited to 3 bouctjes on top of each other
terms_of_use: bookshelf use only
---
Designed to increase storage and then to organize your books.
