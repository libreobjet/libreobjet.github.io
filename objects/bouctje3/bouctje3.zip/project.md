---
object_name: Bouctje3
designer: [Bourg Stefanie, Colart Vicky, Massart Jeromine]
builder: [Bourg Stefanie, Colart Vicky, Massart Jeromine]
category: Showcase bookcase
tags: wood
overall_size: L376 x W308 x H333 mm
creation_date: 2013-10-01
derived_from: Bouctje
original_designer: Mathieu Gabiot
realisation_place: Arts2 - Mons
required_hardware: [jigsaw, hand saw, wood chisel, sander, sand paper]
materials: [plywood panel, screws]
license: Free Art License
client: Workshop Libre Objet

---
Designed to increase storage and then to organize your books.

- improvement: stackability
- advantage: minimal modification form the original design
- disadvantage: limited to 3 bouctjes on top of each other
- terms_of_use: bookshelf use only
