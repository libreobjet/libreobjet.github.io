---
object_name: Mesita
designer: Mathieu Gabiot
builder: Ginger Coons, Wendy Van Wynsberghe
category: side table
tags: wood
creation_date: 2015-12-16
contributors:
derived_from:
realisation_place: Madrid
required_hardware: [cnc milling, drill driver, drill bit 8mm, sander, sand paper, dowels]
license: Free Art License
client: Medialab Prado - Objects in Commons
---

Designed for the exhibition of the workshop results.
