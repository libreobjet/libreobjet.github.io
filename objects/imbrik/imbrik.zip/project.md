---
object_name: Imbrik
designer: [Quaglia Milena, Baise Elodie]
builder: [Quaglia Milena, Baise Elodie]
category: Showcase bookcase
tags: wood
Overall size: 416 x 312 x 308 mm
creation_date: 10-2013
contributors: none
derived_from: Bouctje
Origninal designer/author: Mathieu Gabiot
realisation_place: Art² - Mons
required_hardware: Jigsaw - Drill - Screw Driver - Saw
materials: plywood panel
license: Free Art Licence
client: Workshop Libre Objet
Improvement: folding ability
Advantage: easy to mount and to unmount
Disadvantage: cutting more complex
Terms of use: bookshelf use only
---
sources ready for Conflict & Design - 7th Triennale at C-Mine Genk
