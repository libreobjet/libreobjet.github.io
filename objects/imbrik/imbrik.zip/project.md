---
object_name: Imbrik
designer: [Quaglia Milena, Baise Elodie]
builder: [Quaglia Milena, Baise Elodie]
category: Showcase bookcase
tags: wood
Overall size: 416 x 312 x 308 mm
creation_date: 2013-10-01
contributors:
derived_from: Bouctje
origninal_designer: Mathieu Gabiot
realisation_place: Art² - Mons
required_hardware: [Jigsaw, Drill, Screw Driver, Saw]
materials: plywood panel
license: Free Art License
client: Workshop Libre Objet
---
sources ready for Conflict & Design - 7th Triennale at C-Mine Genk

- Improvement: folding ability
- Advantage: easy to mount and to unmount
- Disadvantage: cutting more complex
- Terms of use: bookshelf use only
