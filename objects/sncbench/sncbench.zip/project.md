---
object_name: Sncbench
designer: [Mathieu Gabiot, Martin Lévêque, Julien Deswaef]
builder: # Full name(s) of builder(s). Ex: [Builder one, Builder two]
category: bench
tags: [hardwood]
overall_size: # Overall size of the object ex: 2500 x 455 x 410 mm
creation_date: 2019-03-07
contributors: []
derived_from: uHBench
original_designer: [Julien Deswaef]
realisation_place: Brussels, Belgium
required_hardware: # List of tools necessary for construction ex: [chainsaw or traditional woodworking tools]
materials: # List of materials [Oak]
license: ﻿Free Art License
client: Constant VZW
---


_Sncbench is a urbanbench._

> description coming soon
